import json
import boto3

def handler(event, context):
       book = json.loads(event['body'])
       key = {
           "id": book['id']
       }
       dynamodb = boto3.resource('dynamodb')
       table = dynamodb.Table('Books2')
       result = table.delete_item(Key=key)

       body = {
            "message": "delete",
            "input": book
       }

       response = {
            "statusCode": result['ResponseMetadata']['HTTPStatusCode'],
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS, POST'
        },
             "body": json.dumps(body)
       }

       return response
