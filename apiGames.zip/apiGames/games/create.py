import json
import boto3

def handler(event, context):
    book = json.loads(event['body'])
    item = {
         "id": book['id'],
         "title":book['title']
    }
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('Books2')
    result = table.put_item(Item=item)
    body = {
        "message": "Create",
        "input": book
    }
    response = {
        "statusCode": result['ResponseMetadata']['HTTPStatusCode'],
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'OPTIONS, POST'
        },
        "body": json.dumps(body)
    }

    return response
